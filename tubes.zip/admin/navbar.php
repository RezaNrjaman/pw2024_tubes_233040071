<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">


<nav class="navbar navbar-expand-lg border-bottom border-body position-fixed top-0 start-0 end-0 z-3 " style="background-color: #1a4d2e; color: #1a4d2e;">
    <div class="container-fluid">
        <form class="d-flex" style="padding-left: 100px;" role="search" method="post" action="">
            <input class="form-control me-2" type="text" name="keyword" placeholder="Search" aria-label="Search" autocomplete="off" id="keyword">
            <button class="btn btn-outline-dark text-white me-3" type="submit" name="cari" id="tombol-cari">Search</button>
        </form>
        <ul class="navbar-nav mb-2 mb-lg-0">
            <li class="nav-item">
                <a class="btn btn-success" aria-current="page" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>